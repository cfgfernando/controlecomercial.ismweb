<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Sistema_model extends CI_Model{


    /**
     *LISTAR TODOS OS DADOS DE UMA TABELA
     */
    public function GetAll($table=NULL, $condicao=NULL)
    {

        if ($tabela) {

            if ($condicao && is_array($condicao)){
                    $this->db->where($condicao);
            }

            $query = $this->db->get($table);
            return $query->result();

        }else{

            return false;
        }

    }

    /**
     *PEGAR APENAS UM REGISTRO DA TABELA PELO ID
     */
    public function GetByID($table=NULL, $condicao=NULL)
    {
        if ($tabela && $condicao && is_array($condicao)) {

                $this->db->where($condicao);
                $this->db->limit(1);
                $query = $this->db->get($table);
                return $query->row();

        }else{

            return false;
        }
    }

    /**
     * INSERIR UM NOVO REGISTRO NA TABELA
     */
    public function DoInsert($table=NULL, $dados=NULL)
    {
        if ($tabela && $dados && is_array($dados)) {

                $this->db->insert($table, $dados);

                if ($this->db->affected_rows()> 0){
                    set_msg('msgsucess', 'Cadastro realizado com sucesso!', 'sucesso');
                }else{
                    set_msg('msgerro', 'Ocorreu um erro ao tentar cadastrar, tente novamente.', 'erro');
                }

        }else{

            return false;
        }
    }
    /**
     * ATUALIZAR UM REGISTRO NA TABELA
     */
    public function DoUpdate($table=NULL, $dados=NULL, $condicao=NULL)
    {
        if ($tabela && $dados && is_array($dados) && $condicao && is_array($condicao)) {

                $this->db->update($table, $dados, $condicao);

            if ($this->db->affected_rows()> 0){
                set_msg('msgsucess', 'Cadastro atualizado com sucesso!', 'sucesso');
            }else{
                set_msg('msgerro', 'Ocorreu um erro ao tentar atualizar, tente novamente.', 'erro');
            }



        }else{

            return false;
        }
    }
    /**
     * APAGAR UM REGISTRO NA TABELA
     */
    public function DoDelete($table=NULL, $condicao=NULL)
    {
        if ($tabela && is_array($condicao)) {

                $this->db->delete($table, $condicao);
            if ($this->db->affected_rows()> 0){
                set_msg('msgsucess', 'Registro apagado com sucesso!', 'sucesso');
            }else{
                set_msg('msgerro', 'Ocorreu um erro ao tentar apagar, tente novamente.', 'erro');
            }

        }else{

            return false;
        }
    }

}



