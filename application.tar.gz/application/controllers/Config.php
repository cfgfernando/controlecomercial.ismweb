<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Config extends CI_Controller{


    public function __construct()
    {
        parent::__construct();
        if (!$this->ion_auth->logged_in())
        {
            set_msg('msgerro', 'Erro: Você precisa estar logado no sistema.', 'erro');
            redirect('login');
        }
        if (!$this->ion_auth->in_group(1))
        {
            set_msg('msgerro', 'Erro: Você não tem permissão para acessar essa página.', 'erro');
            redirect('principal');
        }



    }

    public function index()
    {
       
        $data['dados'] = $this->Sistema_model->GetByID('configuracoes',  array('id_config'=>1));

       // $data['dados'] = $this->Sistema_model->GetByID('configuracoes', array('id_config'=>1));

        echo '<pre>';
            print_r($data['dados']);


        /*$this->load->view('layout/header');
        $this->load->view('config/index', $data);
        $this->load->view('layout/footer');
        */
    }



}
