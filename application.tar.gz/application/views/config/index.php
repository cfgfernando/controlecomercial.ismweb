<div id="page-wrapper">
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                <h3>Configuração</h3>
                <hr />
                <ol class="breadcrumb">
                    <li><a href="/">Principal</a></li>
                    <li class="active">Configurações</li>
                </ol>

            </div>
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <?php
                erros_validacao();
                get_msg('msgerro');
                ?>

            </div>
        </div>

        <!-- formulario de novo registro -->
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <form id="form_add" name="form_add" action="" class="" method="post">

                    <div class="form-group">
                        <label>Razão social</label>
                        <input type="text"
                               class="form-control"
                               name="razao"
                               value="<?php echo set_value('razao', $dados->razao) ?>"
                               placeholder="Razão social">
                    </div>

                    <input type="hidden" value="<?php echo $dados->id_config ?>" name="id_config">
                    <button
                        form="form_add"
                        type="submit"
                        class="btn btn-success">SALVAR</button>
                </form>
            </div>
        </div><!-- / formulario de novo registro -->

    </div>
</div>
