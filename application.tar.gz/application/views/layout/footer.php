


</div>
    <!-- /#wrapper -->
    

    <!-- jQuery -->
    <script src="<?= base_url();?>include/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url();?>include/js/bootstrap.min.js"></script>

    <!-- DataTable -->
     <script src="<?= base_url();?>include/jquery/jquery.datatable/js/dataTables.bootstrap4.js" type="text/javascript"></script>
     <script src="<?= base_url();?>include/jquery/jquery.datatable/js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?= base_url();?>include/jquery/jquery.datatable/js/jquery.dataTables.min.js" type="text/javascript"></script>
   

    <!-- main.js -->
    
    <script src="<?= base_url();?>include/js/main.js" type="text/javascript"></script>

</body>

</html>