<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$autoload['packages'] = array();


$autoload['libraries'] = array('database', 'session', 'ion_auth', 'form_validation');


$autoload['drivers'] = array();


 	
$autoload['helper'] = array('url', 'funcao');

$autoload['config'] = array();


$autoload['language'] = array('auth', 'ion_auth');



$autoload['model'] = array('Sistema_model');
